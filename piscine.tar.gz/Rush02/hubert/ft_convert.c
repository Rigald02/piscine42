/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hde-bels <hde-bels@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 11:35:36 by hde-bels          #+#    #+#             */
/*   Updated: 2021/02/21 16:07:53 by hde-bels         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_below_ten(int nb);
void	ft_ten(int nb);
void	ft_above_ten(int nb);
int		ft_hundred(int nb);

void	ft_convert(int nbr)
{
	if (nbr == 0)
		write(1, "zero", 4);
	if (nbr < 0)
	{
		write(1, "minus", 5);
		nbr *= -1;
	}
	while (nbr != 0)
	{
		if (nbr < 10)
		{
			ft_below_ten(nbr);
			nbr = 0;
		}
		else if (nbr < 20)
		{
			ft_ten(nbr);
			nbr = 0;
		}
		else
			nbr = ft_hundred(nbr);
	}
}
