/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hde-bels <hde-bels@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/20 13:57:39 by hde-bels          #+#    #+#             */
/*   Updated: 2021/02/21 14:04:56 by hde-bels         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_convert(int nbr);

int		check(char *av)
{
	int i;

	i = 0;
	while (av[i] != '\0')
	{
		if (av[i] < '0' || av[i] > '9')
			return (0);
		i++;
	}
	return (1);
}

int		ft_atoi(char *av)
{
	int			i;
	long int	nb;
	long int	neg;

	i = 0;
	neg = 1;
	nb = 0;
	while (av[i] == ' ' || av[i] == '\t' || av[i] == '\v' || av[i] == '\f'
	|| av[i] == '\n' || av[i] == '\r')
		i++;
	while (av[i] == '-' || av[i] == '+')
	{
		if (av[i] == '-')
			neg *= (-1);
		i++;
	}
	while (av[i] >= '0' && av[i] <= '9')
	{
		nb *= 10;
		nb += av[i] - 48;
		i++;
	}
	return (nb * neg);
}

int		main(int ac, char **av)
{
	int	nb;

	if (ac == 2 && check(av[1]) == 1)
	{
		nb = ft_atoi(av[1]);
		ft_convert(nb);
		write(1, "\n", 1);
	}
	else if (ac == 3 && check(av[1]) == 1)
	{
		nb = ft_atoi(av[1]);
	}
	else
		write(1, "Error\n", 6);
	return (0);
}
