/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   overload.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hde-bels <hde-bels@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 14:13:51 by hde-bels          #+#    #+#             */
/*   Updated: 2021/02/21 16:14:12 by hde-bels         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_below_ten(int nb);
void	ft_ten(int nb);
void	ft_above_ten(int nb);
void	ft_convert(int nbr);
int		ft_thousand(int nbr);

int		ft_hundred(int nbr)
{
	int i;

	i = 0;
	if (nbr < 100)
	{
		ft_above_ten(nbr / 10);
		write(1, " ", 1);
		nbr %= 10;
	}
	else if (nbr < 1000)
	{
		i = nbr / 100;
		ft_below_ten(i);
		write(1, " hundred ", 10);
		nbr %= 100;
	}
	else
		nbr = ft_thousand(nbr);
	return (nbr);
}

int		ft_thousand(int nbr)
{
	int i;

	i = 0;
	if (nbr < 10000)
	{
		i = nbr / 1000;
		ft_below_ten(i);
		write(1, " thousand ", 11);
		nbr %= 1000;
	}
	else if (nbr < 100000)
	{
		i = nbr / 10000;
		ft_above_ten(i);
		write(1, " ", 1);
		nbr %= 10000;
	}
	else if (nbr < 1000000)
	{
		i = nbr / 100000;
		ft_below_ten(i);
		write(1, " hundred ", 10);
		nbr %= 100000;
	}
	return (nbr);
}
