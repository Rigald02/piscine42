/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hde-bels <hde-bels@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 10:34:41 by cle-gran          #+#    #+#             */
/*   Updated: 2021/02/25 09:33:29 by hde-bels         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_below_ten(int nb)
{
	if (nb == 1)
		write(1, "one", 3);
	else if (nb == 2)
		write(1, "two", 3);
	else if (nb == 3)
		write(1, "three", 5);
	else if (nb == 4)
		write(1, "four", 4);
	else if (nb == 5)
		write(1, "five", 4);
	else if (nb == 6)
		write(1, "six", 3);
	else if (nb == 7)
		write(1, "seven", 5);
	else if (nb == 8)
		write(1, "eight", 5);
	else if (nb == 9)
		write(1, "nine", 4);
}
git long
void	ft_ten(int nb)
{
	if (nb == 10)
		write(1, "ten", 3);
	else if (nb == 11)
		write(1, "eleven", 6);
	else if (nb == 12)
		write(1, "twelve", 6);
	else if (nb == 13)
		write(1, "thirteen", 8);
	else if (nb == 14)
		write(1, "fourteen", 8);
	else if (nb == 15)
		write(1, "fifteen", 7);
	else if (nb == 16)
		write(1, "sixteen", 7);
	else if (nb == 17)
		write(1, "seventeen", 9);
	else if (nb == 18)
		write(1, "eighteen", 8);
	else if (nb == 19)
		write(1, "nineteen", 8);
}

void	ft_above_ten(int nb)
{
	if (nb == 2)
		write(1, "twenty", 6);
	else if (nb == 3)
		write(1, "thirty", 6);
	else if (nb == 4)
		write(1, "forty", 5);
	else if (nb == 5)
		write(1, "fifty", 5);
	else if (nb == 6)
		write(1, "sixty", 5);
	else if (nb == 7)
		write(1, "seventy", 7);
	else if (nb == 8)
		write(1, "eighty", 6);
	else if (nb == 9)
		write(1, "ninety", 6);

}

void	ft_convert(int nbr)
{
	if (nbr == 0)
		write(1, "zero", 4);
	if (nbr < 0)
	{
		write(1, "minus", 5);
		nbr *= -1;
	}
	while (nbr != 0)
	{
		if (nbr <  10)
		{
			ft_below_ten(nbr);
			nbr = 0;
		}
		else if (nbr < 20)
		{
			ft_ten(nbr);
			nbr = 0;
		}
		else if (nbr < 100)
		{
			ft_above_ten(nbr / 10);
			write(1, " ", 1);
			nbr %= 10;
		}
		else if (nbr < 200)
		{
			write(1, "hundred ", 8);
			nbr %= 100;
		}
	}
}
