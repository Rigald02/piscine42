git ls-files --exclude-standard --ignored --others
